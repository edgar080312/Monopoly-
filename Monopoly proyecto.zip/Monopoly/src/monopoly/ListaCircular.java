
package monopoly;

import java.util.HashSet;
import java.util.Set;


public class ListaCircular {
   
     Nodo inicio;
   
     Nodo ultimo;
    
     int tamanio;
     Jugador jugaux;
    
    public void ListaCircular(int j){
        inicio = null;
        ultimo = null;
        tamanio = 0;
        jugaux=new Jugador(); jugaux.numeroj=j;
        for(int i=0;i<40;i++){
            agregarAlFinal(i);
        }
        ubicarjugador(0);
    }
     public void ubicarjugador(int posicion){

                Nodo aux = inicio;
                
                for (int i = 0; i < posicion; i++) {
                    if(aux.jugado!=null){
                        aux.jugado=null;
                    }
                    aux = aux.getSiguiente();
                }
               
                aux.jugado=jugaux;
            
    }
     public boolean obtenercompra(int posicion){
         Nodo aux=inicio;
         for(int i=0;i<posicion;i++){
             aux=aux.getSiguiente();
         }
         
         return aux.haydueño();
         
         
     }
     public void asignarcompra(int posicion, int s){
       Nodo aux=inicio;
       for(int i=0;i<posicion;i++){
           aux=aux.getSiguiente();
       }
       aux.dueño=s;
     }
     public boolean esVacia(){
        return inicio == null;
    }
     public int getTamanio(){
        return tamanio;
    }
     public void agregarAlFinal(int valor){
        
        Nodo nuevo = new Nodo();
       
        nuevo.setid(valor);
        
        if (esVacia()) {
            
            inicio = nuevo;
           
            ultimo = nuevo;
         
            ultimo.setSiguiente(inicio);
       
        } else{
           
            ultimo.setSiguiente(nuevo);
           
            nuevo.setSiguiente(inicio);
            
            
            ultimo = nuevo;
        }
       
        tamanio++;
        if( valor==2 || valor==7 || valor==17 || valor==22 || valor==33 || valor==36){
            ultimo.setCasillaEspecial();
            
        }
        if(valor==4 || valor==38){
            ultimo.setCasillapago();
            
        }
        if(valor==30){
            ultimo.setCasillacarcel();
        }
        if(valor==0 || valor==20){
            ultimo.casillasalida=true;
        }
        
        if(!ultimo.casillabonus && !ultimo.casillacarcelaria && !ultimo.casillapago && !ultimo.casillasalida){
            ultimo.casillaneutra=true;
        }
    }
     public String obtenertipocasilla(int posicion){
         String tipo=null;
         Nodo aux=inicio;
         for(int i=0;i<posicion;i++){
             aux=aux.getSiguiente();
         }
         if(aux.casillabonus){
           tipo="bonus";
         }
         if(aux.casillacarcelaria){
             tipo="carcel";
         }
         if(aux.casillaneutra){
             tipo="neutra";
         }
         if(aux.casillapago){
             tipo="pago";
         }
         if(aux.casillasalida){
             tipo="salida";
         }
         return tipo;
     }
     public void borrardueñolista(){
         Nodo aux=inicio;
         for(int i=0;i<40;i++){
             if(aux.haydueño()){
                 aux.dueño=0;
             }
             aux=aux.getSiguiente();
         }
     }
     
}
