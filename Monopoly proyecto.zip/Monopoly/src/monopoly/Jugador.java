
package monopoly;


public class Jugador {
    int numeroj;
    int dinero=100;
    int posiciontablero=0;
    int npropiedades=0;
    boolean compra=false;
    boolean bancarota=false;
    boolean preso=false;
}
