
package monopoly;

import java.io.IOException;
import java.util.Scanner;


public class Monopoly {

    
    public static void main(String[] args) throws IOException {
      Scanner sc=new Scanner(System.in);
        Juego juego=new Juego();
      juego.Juego();
      
      
      
      while(!juego.ganador){
        for(int i=0;i<4;i++){
            int x=0;
            x=0;
            if(!juego.listac[i].jugaux.bancarota){
            juego.turno(i);
            }
            if(juego.listac[0].jugaux.bancarota){
              x+=1;  
            }
            if(juego.listac[1].jugaux.bancarota){
              x+=1;  
            }
            if(juego.listac[2].jugaux.bancarota){
              x+=1;  
            }
            if(juego.listac[3].jugaux.bancarota){
              x+=1;  
            }
            if(x==3){
                juego.ganador=true;
            }
            
        }
      }
      if(juego.ganador){
         for(int i=0;i<4;i++){
             if(!juego.listac[i].jugaux.bancarota){
                 juego.ganadorn=juego.listac[i].jugaux.numeroj;
             }
         } 
      }
        System.out.println("El ganador de la partida es el jugador "+juego.ganadorn);
       
      Texto tx=new Texto();
       tx.crear("ganadoresdelmonopoly.txt", juego.ganadorn);
      
      
      
    }
    
}

