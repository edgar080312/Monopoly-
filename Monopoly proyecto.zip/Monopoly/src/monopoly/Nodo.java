
package monopoly;


public class Nodo {
    
    int id;
    int dueño;
    int costo=20;
    int alquiler=10;
    boolean casillaneutra=false;
    boolean casillabonus=false;
    boolean casillacarcelaria=false;
    boolean casillapago=false;
    boolean casillasalida=false;
    Jugador jugado=new Jugador();
    
     Nodo siguiente;
     
    /**
     * Constructor que inicializamos el valor de las variables.
     */
    public void Nodo(){
        this.id = 0;
        this.siguiente = null;
        this.dueño=0;
    }
    public void setCasillaEspecial(){
        casillabonus=true;
    }
    public void setCasillacarcel(){
        casillacarcelaria=true;
    }
    public void setCasillapago(){
        casillapago=true;
    }
    public boolean haydueño(){
        if(dueño!=0){
            return true;
        }else{
              return false;
                }
    }
    
    
    // Métodos get y set para los atributos.
    
    public int getid() {
        return id;
    }

    public void setid(int valor) {
        this.id = valor;
    }
    
    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
    public void setdueño(int dueñ){
        dueño=dueñ;
    }
    public void setjugador(Jugador j){
        jugado=j;
        
    }
}
