
package monopoly;

import java.util.Scanner;


public class Juego {
 ListaCircular[] listac=new ListaCircular[4];
boolean ganador=false;
int ganadorn;

Dado dado=new Dado();
int dueñoaux;
public void Juego(){
  listac[0]=new ListaCircular(); listac[0].ListaCircular(1);
  listac[1]=new ListaCircular(); listac[1].ListaCircular(2);
  listac[2]=new ListaCircular(); listac[2].ListaCircular(3);
  listac[3]=new ListaCircular(); listac[3].ListaCircular(4); 
}
public void turno(int i){
    if(!ganador){
    Scanner sc=new Scanner(System.in);
   int w=dado.lanzarDado();
   if(!listac[i].jugaux.preso){
   listac[i].jugaux.posiciontablero+=w;
   if(listac[i].jugaux.posiciontablero>40){
      listac[i].jugaux.posiciontablero-=39;
      listac[i].jugaux.dinero+=20;
      listac[i].ubicarjugador(listac[i].jugaux.posiciontablero);
   }else{
       listac[i].ubicarjugador(listac[i].jugaux.posiciontablero);
   }
   System.out.println("El jugador "+listac[i].jugaux.numeroj+" ha lanzado un "+w+" y se encuentra en la posicion numero "+listac[i].jugaux.posiciontablero);
   if(listac[i].obtenertipocasilla(listac[i].jugaux.posiciontablero).equals("neutra")){
   if(recorrerlistaboolean(listac[i].jugaux.posiciontablero)){
       recorrerlistasdueño(listac[i].jugaux.posiciontablero);
       if(dueñoaux==listac[i].jugaux.numeroj){
           System.out.println("El jugador es dueño de esta propiedad");
       }else{
           System.out.println("Propiedad del jugador numero "+dueñoaux+" se le pagara alquiler");
       listac[i].jugaux.dinero-=10;
       if(listac[i].jugaux.dinero>0){
           System.out.println("El jugador numero "+listac[i].jugaux.numeroj+" tiene "+listac[i].jugaux.dinero);
       }else{
           System.out.println("El jugador numero "+listac[i].jugaux.numeroj+" ha quedado en bancarrota");
           listac[i].jugaux.bancarota=true;
           listac[i].borrardueñolista();
       }
       listac[dueñoaux-1].jugaux.dinero+=10;
           System.out.println("El jugador "+dueñoaux+" ahora tiene "+listac[dueñoaux-1].jugaux.dinero);
       
       }
   }else{
       System.out.println("Propiedad sin dueño, ingrese 1 si desea comprarla (debe tener mas de 20 o ira a bancarrota) o cualquier otro numero en caso contrario");
       int compra=sc.nextInt();
       switch(compra){
           case 1:listac[i].jugaux.dinero-=20;
           if(listac[i].jugaux.dinero>0){
           listac[i].jugaux.npropiedades+=1;
           listac[i].asignarcompra(listac[i].jugaux.posiciontablero, listac[i].jugaux.numeroj);
               System.out.println("Compra realizada con exito, ahora el jugador "+listac[i].jugaux.numeroj+" posee la propiedad de la casilla "+listac[i].jugaux.posiciontablero);
                   }else{
               System.out.println("El jugador "+listac[i].jugaux.numeroj+" no tenia suficiente y ha quebrado");
               listac[i].jugaux.bancarota=true;
               listac[i].borrardueñolista();
           }
           break;
           default: System.out.println("Turno pasara al siguiente jugador");
       }

   }
   }
   
   if(listac[i].obtenertipocasilla(listac[i].jugaux.posiciontablero).equals("pago")){
       System.out.println("El jugador "+listac[i].jugaux.numeroj+" cayo en una casilla de impuestos, se le cobrara 25");
       listac[i].jugaux.dinero-=25;
       if(listac[i].jugaux.dinero>0){
       System.out.println("Ahora el jugador numero "+listac[i].jugaux.numeroj+" posee "+listac[i].jugaux.dinero);
       }else{
           System.out.println("El jugador "+listac[i].jugaux.numeroj+" ha quebrado");
           listac[i].jugaux.bancarota=true;
           listac[i].borrardueñolista();
       }
   }
   if(listac[i].obtenertipocasilla(listac[i].jugaux.posiciontablero).equals("bonus")){
       System.out.println("El jugador "+listac[i].jugaux.numeroj+" cayo en una casilla de bonus, se le sumara 20");
       listac[i].jugaux.dinero+=20;
       System.out.println("Ahora el jugador "+listac[i].jugaux.numeroj+" posee "+listac[i].jugaux.dinero);
   }
   if(listac[i].obtenertipocasilla(listac[i].jugaux.posiciontablero).equals("carcel")){
       listac[i].ubicarjugador(10);
       listac[i].jugaux.preso=true;
       System.out.println("El jugador ha caido preso y ha sido llevado a la carcel de la casilla 10,");
   }
   if(listac[i].obtenertipocasilla(listac[i].jugaux.posiciontablero).equals("salida")){
       System.out.println("Caiste en parada libre o en go, se añadiran un monto de ser necesario");
      
   }
   }else{
       System.out.println("El jugador "+listac[i].jugaux.numeroj+" esta preso, lanzara el dado y pagara 10 veces lo que salga para salir de la carcel en el siguiente turno");
       System.out.println("Lanzo un "+w+" por lo que pagara "+w*10+" para salir en el siguiente turno de la carcel, si se queda sin dinero pierde");
       listac[i].jugaux.dinero-=w*10;
       if(listac[i].jugaux.dinero<=0){
           listac[i].jugaux.bancarota=true;
           System.out.println("El jugador "+listac[i].jugaux.numeroj+"  no le alcanzo para pagar la fianza y ha quebrado");
           listac[i].borrardueñolista();
       }else{
          listac[i].jugaux.preso=true; 
       }
   }
   if(listac[i].jugaux.npropiedades==28){
       ganador=true;
       ganadorn=listac[i].jugaux.numeroj;
   }
   for(int x=0;x<4;x++){
       int y=0;
    if(listac[x].jugaux.bancarota){
        y+=1;
    }
    if(y==3){
        ganador=true;
        for(int d=0;d<4;d++){
            if(!listac[d].jugaux.bancarota){
                ganadorn=listac[d].jugaux.numeroj;
            }
        }
    }
}

    }else{
        System.out.println("El ganador es el jugador "+ganadorn);
    }  
}
public void recorrerlistasdueño(int posicion){
    for (int i=0;i<4;i++){
       if (listac[i].obtenercompra(posicion)){
           dueñoaux=listac[i].jugaux.numeroj;
       }
    }
}
public void recorrerlistadueñoborrar(){
    for(int i=0;i<4;i++){
        
    }
}
public boolean recorrerlistaboolean(int pois){
    boolean bandera=false;
    for(int i=0;i<4;i++){
        if(listac[i].obtenercompra(pois)){
           bandera=true;
        }
        
    }
    return bandera;
}
public void recorrerlistatipocasilla(){

}

}
