
package monopoly;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Texto {
    PrintWriter pw;
    FileReader fr;
    String nombre1;
    
    void crear(String pNombre,int pDatos) throws IOException
    {
        pw=new PrintWriter(new FileWriter(pNombre, true));
        pw.println(" El ganadr de la partida fue el jugador numero: "+pDatos);
        pw.close();
        System.out.println("Generacion del archivo completada, busque el archivo llamado ganadoresdelmonopoly.txt en la carpeta de este programa");
        
    }
}
